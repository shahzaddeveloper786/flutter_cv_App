class product {
  String image;
  String name;
  String discription;

  product(
    this.image,
    this.name,
    this.discription,
  );
}
