import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:my_cv_project/listview/model.dart';

class Productdetail extends StatefulWidget {
  product p;

  Productdetail(this.p);

  @override
  State<Productdetail> createState() => _State();
}

class _State extends State<Productdetail> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          iconTheme: IconThemeData(color: Colors.white),
          centerTitle: true,
          backgroundColor: Colors.black,
          title: Text(
            widget.p.name,
            style: TextStyle(
                color: Colors.white, fontSize: 25, fontWeight: FontWeight.bold),
          ),
        ),
        body: Container(
          width: double.maxFinite,
          color: Colors.blue.shade50,
          child: SingleChildScrollView(
              child: Column(children: [
            SizedBox(
              height: 5,
            ),
            Container(
              width: double.maxFinite,
              height: 400,
              color: Colors.black12,
              child: Image.asset(
                widget.p.image,
              ),
            ),
            SizedBox(
              height: 10,
            ),
            Align(
                alignment: Alignment.centerLeft,
                child: Text(
                  widget.p.name,
                  style: TextStyle(
                      color: Colors.black,
                      fontSize: 25,
                      fontWeight: FontWeight.bold),
                )),
            SizedBox(
              height: 10,
            ),
            Container(
                color: Colors.orange,
                width: double.maxFinite,
                padding: EdgeInsets.all(15),
                child: Text(
                  "Discription",
                  style: TextStyle(
                      color: Colors.black,
                      fontSize: 20,
                      fontWeight: FontWeight.bold),
                )),
            Container(
                color: Colors.white,
                child: Text(
                  widget.p.discription,
                  style: TextStyle(
                    color: Colors.black,
                    fontSize: 20,
                  ),
                )),
          ])),
        ));
  }
}
