import 'package:flutter/material.dart';
import 'package:my_cv_project/listview/container.dart';
import 'package:my_cv_project/listview/model.dart';
import 'package:my_cv_project/listview/prodct_card.dart';
import 'package:my_cv_project/listview/product_detail.dart';
import 'package:my_cv_project/portfio/my_custom_drawer.dart';

class ListScreen extends StatefulWidget {
  @override
  State<ListScreen> createState() => ListScreenstate();
}

class ListScreenstate extends State<ListScreen> {
  List<product> data = [];
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    data = Productsdata().getAllProduct();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.blue.shade50,
      appBar: AppBar(
        iconTheme: IconThemeData(color: Colors.white),
        backgroundColor: Colors.black,
        centerTitle: true,
        title: Text(
          "My Portfolio",
          style: TextStyle(color: Colors.white),
        ),
      ),
      drawer: Mycustomdrawer(),
      body: Container(
          child: ListView.builder(
              itemCount: data.length,
              itemBuilder: (context, index) {
                product p = data[index];
                return InkWell(
                  child: productcontainer(p),
                  onTap: () => Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => Productdetail(p))),
                );
              })),
    );
  }
}
