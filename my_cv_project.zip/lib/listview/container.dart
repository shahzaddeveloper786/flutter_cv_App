import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:my_cv_project/listview/model.dart';

class productcontainer extends StatelessWidget {
  product p;
  productcontainer(this.p);
  @override
  Widget build(BuildContext context) {
    return Container(
      height: 150,
      width: double.maxFinite,
      margin: EdgeInsets.all(10),
      color: Colors.orange,
      child: Padding(
          padding: EdgeInsets.all(5),
          child: Row(
            children: [
              SizedBox(
                width: 5,
              ),
              Image.asset(
                p.image,
              ),
              SizedBox(
                width: 20,
              ),
              Column(
                children: [
                  Align(
                    alignment: Alignment.topLeft,
                    child: Text(
                      p.name,
                      style: TextStyle(color: Colors.black, fontSize: 25),
                    ),
                  ),
                  SizedBox(
                    height: 20,
                  ),
                  Container(
                    color: Colors.white,
                    height: 40,
                    alignment: Alignment.center,
                    child: Text(
                      " View Project ",
                      style: TextStyle(
                          color: Colors.black,
                          fontWeight: FontWeight.bold,
                          fontSize: 20),
                    ),
                  ),
                ],
              ),
              SizedBox(
                width: 5,
              ),
            ],
          )),
    );
  }
}
