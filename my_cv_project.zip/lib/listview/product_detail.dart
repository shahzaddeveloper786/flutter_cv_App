import 'package:my_cv_project/listview/model.dart';

class Productsdata {
  List<product> getAllProduct() {
    List<product> myData = [];
    product p1 = product("assets/Images/LS.png", "Login Screen",
        "Portfolio Example Project: A fully functional user authentication screen built using Flutter. This project demonstrates custom form validation (including email and password checks), state management, smooth navigation between login and home screens, and clean UI design with responsive text fields.");
    myData.add(p1);
    product p2 = product("assets/Images/PS.png", "Profile Screen",
        "Portfolio Example Project: A beautifully designed user profile interface in Flutter. This project showcases advanced UI layout structuring, custom card widgets, clean typography, profile avatars, and structured contact details layout to highlight professional developer profiles.");
    myData.add(p2);
    return myData;
  }
}
