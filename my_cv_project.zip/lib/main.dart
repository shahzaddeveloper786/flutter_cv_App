import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:my_cv_project/portfio/first_screen.dart';

void main() async {
  // Flutter bindings initialize karein
  WidgetsFlutterBinding.ensureInitialized();

  // Firebase initialize karein (Correct Syntax)
  await Firebase.initializeApp(
    options: const FirebaseOptions(
      apiKey: "AIzaSyA8-XEvQ4MUOmo5YoDYxB3EYZ8oixEkkS4",
      authDomain: "mycvproject-3dc4b.firebaseapp.com",
      projectId: "mycvproject-3dc4b",
      storageBucket: "mycvproject-3dc4b.firebasestorage.app",
      messagingSenderId: "832277375088",
      appId: "1:832277375088:web:692be229057265d524ecb5",
    ),
  );

  runApp(MaterialApp(
    //debug hataiey gah
    debugShowCheckedModeBanner: false,
    //screen load kare gah
    home: Firstscreen(),
  ));
}
