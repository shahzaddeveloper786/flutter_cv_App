import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:my_cv_project/portfio/my_custom_drawer.dart';

class Secondscreen extends StatefulWidget {
  @override
  State<Secondscreen> createState() => _SecondscreenState();
}

class _SecondscreenState extends State<Secondscreen> {
  TextEditingController namecontroller = TextEditingController();
  TextEditingController emailcontroller = TextEditingController();
  TextEditingController messagecontroller = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Colors.blue.shade50,
        appBar: AppBar(
          iconTheme: IconThemeData(color: Colors.white),
          backgroundColor: Colors.black,
          centerTitle: true,
          title: Text(
            "Contact Me",
            style: TextStyle(color: Colors.white),
          ),
        ),
        drawer: Mycustomdrawer(),
        body: ListView(
          children: [
            SizedBox(height: 10),
            Padding(
                padding: EdgeInsets.only(left: 10, right: 10),
                child: TextField(
                  controller: namecontroller,
                  keyboardType: TextInputType.name,
                  decoration: InputDecoration(
                    prefixIcon: Icon(Icons.person),
                    labelText: 'write your name',
                    border: OutlineInputBorder(),
                    enabledBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.black),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.orange),
                    ),
                  ),
                )),
            SizedBox(height: 16),
            Padding(
                padding: EdgeInsets.only(left: 10, right: 10),
                child: TextField(
                  controller: emailcontroller,
                  keyboardType: TextInputType.emailAddress,
                  decoration: InputDecoration(
                    prefixIcon: Icon(Icons.email),
                    labelText: 'Write your email',
                    border: OutlineInputBorder(),
                    enabledBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.black),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.orange),
                    ),
                  ),
                )),
            SizedBox(height: 16),
            Padding(
                padding: EdgeInsets.only(left: 10, right: 10),
                child: TextField(
                  controller: messagecontroller,
                  maxLines: 8,
                  decoration: InputDecoration(
                    labelText: 'Write your massage',
                    alignLabelWithHint: true,
                    border: OutlineInputBorder(),
                    enabledBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.black),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.orange),
                    ),
                  ),
                )),
            SizedBox(height: 20),
            Align(
                alignment: Alignment.center,
                child: InkWell(
                  onTap: sendMessageToFirebase,
                  child: Container(
                    height: 50,
                    width: 150,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(25),
                      color: Colors.orange,
                    ),
                    alignment: Alignment.center,
                    child: Text(
                      "Submit",
                      style: TextStyle(
                          color: Colors.black,
                          fontSize: 25,
                          fontWeight: FontWeight.bold),
                    ),
                  ),
                )),
          ],
        ));
  }

  Future<void> sendMessageToFirebase() async {
    // 1. Email validation ke liye Regular Expression (RegEx)
    RegExp emailRegExp = RegExp(
      r"^[a-zA-Z0-9.a-zA-Z0-9.!#$%&'*+-/=?^_`{|}~]+@[a-zA-Z0-9]+\.[a-zA-Z]+",
    );

    // 2. Check karein ke saari fields bhari hain ya nahi
    if (namecontroller.text.trim().isEmpty ||
        emailcontroller.text.trim().isEmpty ||
        messagecontroller.text.trim().isEmpty) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Please fill out all fields!')),
        );
      }
      return;
    }

    // 3. Check karein ke email ka format sahi hai ya nahi
    if (!emailRegExp.hasMatch(emailcontroller.text.trim())) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Please enter a valid email address!')),
        );
      }
      return; // Form yahin ruk jayega aur submit nahi hoga
    }

    try {
      await FirebaseFirestore.instance
          .collection('contact_messages')
          .doc(namecontroller.text.trim())
          .set({
        'name': namecontroller.text.trim(),
        'email': emailcontroller.text.trim(),
        'message': messagecontroller.text.trim(),
        'timestamp': FieldValue.serverTimestamp(),
      });

      namecontroller.clear();
      emailcontroller.clear();
      messagecontroller.clear();

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
              content: Text('Your message has been successfully sent!')),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error: $e')),
        );
      }
    }
  }
}
