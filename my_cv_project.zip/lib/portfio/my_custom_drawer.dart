//yeh mera custom drawer hai
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:my_cv_project/listview/list_screen.dart';
import 'package:my_cv_project/portfio/first_screen.dart';
import 'package:my_cv_project/portfio/second_screen.dart';

class Mycustomdrawer extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
// TODO: implement build

    return Padding(
      padding: EdgeInsets.only(top: 50),
      child: Drawer(
        width: 200,
        backgroundColor: Colors.blue.shade50,
        child: SingleChildScrollView(
          child: Column(
            children: [
              UserAccountsDrawerHeader(
                  currentAccountPicture: CircleAvatar(
                    backgroundImage: AssetImage("assets/Images/PM.png"),
                  ),
                  //name show ho gah
                  decoration: BoxDecoration(color: Colors.blue.shade400),
                  accountName: Text(
                    "Shahzad Rafique",
                    style: TextStyle(
                        color: Colors.black,
                        fontSize: 20,
                        fontWeight: FontWeight.bold),
                  ),
                  //email show ho gah
                  accountEmail: Text(
                    "hafizshahzadrafique@outlook.com",
                    style: TextStyle(
                      color: Colors.black,
                      fontSize: 10,
                    ),
                  )),
              SizedBox(
                height: 20,
              ),
              InkWell(
                child: ListTile(
                  leading: Icon(Icons.person),
                  title: Text("Introduction"),
                ),
                onTap: () {
                  Navigator.pop(context);
                  Navigator.push(context,
                      MaterialPageRoute(builder: (context) => Firstscreen()));
                },
              ),
              InkWell(
                child: ListTile(
                  leading: Icon(Icons.file_open_sharp),
                  title: Text("Portfolio"),
                ),
                onTap: () {
                  Navigator.pop(context);
                  Navigator.push(context,
                      MaterialPageRoute(builder: (context) => ListScreen()));
                },
              ),
              InkWell(
                child: ListTile(
                  leading: Icon(Icons.phone),
                  title: Text("Contat Me"),
                ),
                onTap: () {
                  Navigator.pop(context);
                  Navigator.push(context,
                      MaterialPageRoute(builder: (context) => Secondscreen()));
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}
