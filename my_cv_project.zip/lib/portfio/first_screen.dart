import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:my_cv_project/portfio/my_custom_drawer.dart';

class Firstscreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Colors.blue.shade50,
        //app bar show ho gih
        appBar: AppBar(
          iconTheme: IconThemeData(color: Colors.white),
          backgroundColor: Colors.black,
          centerTitle: true,
          title: Text(
            "Introduction",
            style: TextStyle(color: Colors.white),
          ),
        ),
        //drawer show ho gah
        drawer: Mycustomdrawer(),
        //body mein container show ho gah
        body: Container(
            height: double.maxFinite,
            child: SingleChildScrollView(
                child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                  SizedBox(
                    height: 10,
                  ),
                  //image show ho gah
                  CircleAvatar(
                    radius: 50,
                    backgroundImage: AssetImage("assets/Images/PM.png"),
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  //name show ho gah
                  Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                    Text("Shahzad Rafique",
                        style: TextStyle(
                            color: Colors.black,
                            fontSize: 25,
                            fontWeight: FontWeight.bold)),
                  ]),
                  //row mein uhdah show ho gah
                  Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                    Text("Flutter developer",
                        style: TextStyle(
                          color: Color(0x61131212),
                          fontSize: 20,
                        )),
                  ]),
                  SizedBox(
                    height: 10,
                  ),
                  //orange colour ke container mein aboutme show ho gah
                  Container(
                      margin: EdgeInsets.only(left: 15, right: 15),
                      color: Colors.orange,
                      child: Align(
                        alignment: Alignment.centerLeft,
                        child: Padding(
                          padding: EdgeInsets.all(15),
                          child: Text(
                            "About me:",
                            textAlign: TextAlign.start,
                            style: TextStyle(
                              color: Colors.black,
                              fontWeight: FontWeight.bold,
                              fontSize: 24,
                            ),
                          ),
                        ),
                      )),
                  //description show ho gih white container mein
                  Container(
                      margin: EdgeInsets.only(left: 15, right: 15),
                      width: double.maxFinite,
                      color: Colors.white,
                      child: Padding(
                          padding: EdgeInsets.only(left: 15, right: 15),
                          child: Text(
                            textAlign: TextAlign.justify,
                            "Detail-oriented Flutter Developer with experience in building smooth, high-performance cross-platform mobile apps using Dart, REST APIs, and Firebase. Passioned about writing clean code and creating responsive user interfaces for Android and iOS.",
                            style: TextStyle(
                              color: Colors.black,
                              fontSize: 18,
                            ),
                          ))),
                  SizedBox(
                    height: 15,
                  ),
                  //orange color ke container mein core skill show ho gah
                  Container(
                      margin: EdgeInsets.only(left: 15, right: 15),
                      color: Colors.orange,
                      child: Align(
                        alignment: Alignment.centerLeft,
                        child: Padding(
                          padding: EdgeInsets.all(15),
                          child: Text(
                            "Core Skills",
                            textAlign: TextAlign.start,
                            style: TextStyle(
                              color: Colors.black,
                              fontWeight: FontWeight.bold,
                              fontSize: 24,
                            ),
                          ),
                        ),
                      )),
                  //rows mein skills detail show hoon gih
                  Container(
                      margin: EdgeInsets.only(left: 15, right: 15),
                      width: double.maxFinite,
                      color: Colors.white,
                      child: Padding(
                          padding: EdgeInsets.only(left: 15, right: 15),
                          child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  "Flutter & Dart:",
                                  style: TextStyle(
                                      color: Colors.black,
                                      fontSize: 18,
                                      fontWeight: FontWeight.bold),
                                ),
                                Text(
                                  "Cross-Platform Mobile Apps Development",
                                  style: TextStyle(
                                      color: Colors.black, fontSize: 18),
                                ),
                                Text(
                                  "APIs:",
                                  style: TextStyle(
                                      color: Colors.black,
                                      fontSize: 18,
                                      fontWeight: FontWeight.bold),
                                ),
                                Text(
                                  "REST APIs Integration & JSON Parsing",
                                  style: TextStyle(
                                      color: Colors.black, fontSize: 18),
                                ),
                                Text(
                                  "Database:",
                                  style: TextStyle(
                                      color: Colors.black,
                                      fontSize: 18,
                                      fontWeight: FontWeight.bold),
                                ),
                                Text(
                                  "Firebase Authentication & Firestore Database",
                                  style: TextStyle(
                                      color: Colors.black, fontSize: 18),
                                ),
                                Text(
                                  "UI/UX:",
                                  style: TextStyle(
                                      color: Colors.black,
                                      fontSize: 18,
                                      fontWeight: FontWeight.bold),
                                ),
                                Text(
                                  "Responsive User Interfaces for Android & iOS",
                                  style: TextStyle(
                                      color: Colors.black, fontSize: 18),
                                ),
                                Text(
                                  "Code Quality:",
                                  style: TextStyle(
                                      color: Colors.black,
                                      fontSize: 18,
                                      fontWeight: FontWeight.bold),
                                ),
                                Text(
                                  "Clean Code Architecture & State Management",
                                  style: TextStyle(
                                      color: Colors.black, fontSize: 18),
                                ),
                              ]))),
                  SizedBox(
                    height: 15,
                  ),
                  //orange color ke container mein tools and tecnology show ho gah
                  Container(
                      margin: EdgeInsets.only(left: 15, right: 15),
                      color: Colors.orange,
                      child: Align(
                        alignment: Alignment.centerLeft,
                        child: Padding(
                          padding: EdgeInsets.all(15),
                          child: Text(
                            "Tools & Technologies:",
                            textAlign: TextAlign.start,
                            style: TextStyle(
                              color: Colors.black,
                              fontWeight: FontWeight.bold,
                              fontSize: 24,
                            ),
                          ),
                        ),
                      )),
                  //white color ke container mein tools show hon geh
                  Container(
                      margin: EdgeInsets.only(left: 15, right: 15),
                      padding: EdgeInsets.all(15),
                      color: Colors.white,
                      width: double.maxFinite,
                      child: Padding(
                          padding: EdgeInsets.only(left: 15, right: 15),
                          child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text("• VS Code, Android Studio",
                                    style: TextStyle(
                                        fontSize: 18,
                                        fontWeight: FontWeight.w500)),
                                SizedBox(height: 5),
                                Text("• Firebase",
                                    style: TextStyle(
                                        fontSize: 18,
                                        fontWeight: FontWeight.w500)),
                              ])))
                ]))));
  }
}
